/**
 * 
 */
package com.mycompany.basicmathoperations.oop;

/**
 * @author ilker
 *
 */
public interface Has2numbers {
	public Float getNumber1();
	public Float getNumber2();
}