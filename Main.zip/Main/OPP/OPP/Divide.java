/**
 * 
 */
package com.mycompany.basicmathoperations.oop;

/**
 * @author ilker
 *
 */
public interface Divide {
	public int   divide(int num1, int num2);
	public float divide(float num1, float num2);
	public float divide2numbers();
}