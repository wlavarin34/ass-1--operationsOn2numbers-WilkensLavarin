/**
 * 
 */
package com.mycompany.basicmathoperations.oop;

/**
 * @author ilker
 *
 */
public interface Addition {
	public int   addition(int num1, int num2);
	public float addition(float num1, float num2);
	public float add2numbers();
}