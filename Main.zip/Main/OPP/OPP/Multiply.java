/**
 * 
 */
package com.mycompany.basicmathoperations.oop;

/**
 * @author ilker
 *
 */
public interface Multiply {
	public int   multiply(int num1, int num2);
	public float multiply(float num1, float num2);
	public float multiply2numbers();
}