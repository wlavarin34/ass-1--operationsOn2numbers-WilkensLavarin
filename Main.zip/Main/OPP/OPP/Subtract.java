/**
 * 
 */
package com.mycompany.basicmathoperations.oop;

/**
 * @author ilker
 *
 */
public interface Subtract {
	public int   Subtraction(int num1, int num2);
	public float Subtraction(float num1, float num2);
	public float subtract2numbers();
}